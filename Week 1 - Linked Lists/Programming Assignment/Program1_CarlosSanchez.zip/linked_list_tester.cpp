/*
 * Programming Assignment 1
 * Abstract: Linked list programming assignment that loops
 * through lists and displays the substrings that start with
 * A and end with B.
 * Author: Carlos Sanchez
 * ID: 003065256
 * Date: January 15, 2019
 */


#include <iostream>
using namespace std;

#include <iostream>
#include <string>


#include "LinkedList.h"

int main()
{
//	// Test the class constructor
//	LinkedList intList;
//	cout << "Constructing intList\n";
//
//	// Test insert()
//	intList.insert(300, 0);
//	intList.display(cout);
//	cout << endl;
//
//	intList.insert(200, 0);
//	intList.display(cout);
//	cout << endl;
//
//	intList.insert(100, 0);
//	intList.display(cout);
//	cout << endl;
//
//	intList.insert(400, 3);
//	intList.display(cout);
//	cout << endl;
//
//	intList.insert(900, 4);
//	intList.display(cout);
//	cout << endl;
//
//	//Test isAscendingOrder
//	cout << "\nIs it in ascending order?: " << intList.isAscendingOrder()<< endl;
//
//	//Test maxItem
//	cout << "\nMax is "<< intList.maxItem()<< endl;
//
//	// Test destructor
//	{
//		LinkedList anotherList;
//		for (int i = 0; i < 10; i++)
//		{
//			anotherList.insert(100*i, i);
//		}
//		cout << "\nThis is another list\n";
//		anotherList.display(cout);
//	}
//
//	// Test erase
//	intList.erase(1);
//	intList.erase(1);
//	cout << "\n\nTwo items are erased from the first list\n";
//	intList.display(cout);
//	cout << endl;


   {
	LinkedList stringList;

	string userInput;
	cout << "Enter a string : ";
	cin >> userInput;
	stringList.stringToList(userInput);
	stringList.findSubstrings();
   }

}
